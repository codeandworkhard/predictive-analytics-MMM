import pandas as pd

from src.config import DATE_COLUMN, RAW_DATA_PATH


def load_dataset(path=RAW_DATA_PATH) -> pd.DataFrame:
    """Load the coursework dataset with parsed dates."""
    df = pd.read_csv(path)
    df[DATE_COLUMN] = pd.to_datetime(df[DATE_COLUMN])
    return df.sort_values(DATE_COLUMN).reset_index(drop=True)
