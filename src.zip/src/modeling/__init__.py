"""Model training helpers."""
