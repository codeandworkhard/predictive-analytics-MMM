import pandas as pd

from src.config import DATE_COLUMN


def chronological_split(
    df: pd.DataFrame,
    train_frac: float = 0.7,
    validation_frac: float = 0.15,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split a dataframe into chronological train, validation, and test sets."""
    ordered = df.sort_values(DATE_COLUMN).reset_index(drop=True)
    n_rows = len(ordered)
    train_end = int(n_rows * train_frac)
    validation_end = int(n_rows * (train_frac + validation_frac))
    return (
        ordered.iloc[:train_end].copy(),
        ordered.iloc[train_end:validation_end].copy(),
        ordered.iloc[validation_end:].copy(),
    )
