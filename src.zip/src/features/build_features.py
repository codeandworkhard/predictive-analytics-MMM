import pandas as pd

from src.config import DATE_COLUMN, GROUP_COLUMN, LEAKAGE_PRONE_COLUMNS, PRIMARY_TARGET


def build_feature_frame(df: pd.DataFrame, target: str = PRIMARY_TARGET) -> tuple[pd.DataFrame, pd.Series]:
    """Create a simple starter feature matrix for baseline experiments."""
    frame = df.copy()
    frame[DATE_COLUMN] = pd.to_datetime(frame[DATE_COLUMN])
    frame["day_of_week"] = frame[DATE_COLUMN].dt.dayofweek
    frame["month"] = frame[DATE_COLUMN].dt.month
    frame["quarter"] = frame[DATE_COLUMN].dt.quarter

    numeric_features = [
        col
        for col in frame.columns
        if col not in {target, DATE_COLUMN, GROUP_COLUMN}
        and col not in LEAKAGE_PRONE_COLUMNS
        and pd.api.types.is_numeric_dtype(frame[col])
    ]

    X = frame[numeric_features + ["day_of_week", "month", "quarter"]].fillna(0)
    y = frame[target]
    return X, y
